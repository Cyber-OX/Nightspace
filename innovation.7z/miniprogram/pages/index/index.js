const db=wx.cloud.database();
const message =db.collection("message")

Page({
    data:{
        li:['时间排序','种类排序','',''],
        shownavindex:0,
        current: "",
        userInfo: {},
        hasUserInfo: false,
        canIUse: wx.canIUse('button.open-type.getUserInfo'),
        canIUseGetUserProfile: false,
        canIUseOpenData: wx.canIUse('open-data.type.userAvatarUrl') && wx.canIUse('open-data.type.userNickName') ,
        showRigh2: false,
        img_urls: [],
        message:[],

    },
    
    
    onLoad: function(options) {
        //展现药品信息的代码
        message.get().then(res=>{
          console.log("22",res.data)
          this.setData({
            message:res.data
          })
        })
        /**
         * 调用云函数获取云数据库中的图片id，云函数相关内容可以参考：https://www.ourspark.org/point/course_content/602df4b15165a14f347bb48b,%E5%B0%8F%E7%A8%8B%E5%BA%8F%E4%BA%91%E5%BC%80%E5%8F%91,%E4%BA%91%E5%87%BD%E6%95%B0
        */
        wx.cloud.callFunction({
          name: 'uploadImage',
          data: {
            type: 'getUrls'
          }
        })
        .then(res => {
            
          if (res.result.state) {
            for (let i in res.result.data.data) {
              this.data.img_urls.push(res.result.data.data[i].file_id);
            }
            console.log(this.data.img_urls)
            this.setData({
              img_urls: this.data.img_urls
            })
            console.log(this.data.img_urls)
          }
          else {
            throw(res.result.message);
          }
        })
        .catch(err => {
          console.log('获取图片url列表错误', err);
        })
      },
    
      handleChange ({ detail }) {
        console.log(detail.key)
        this.setData({
            current: detail.key
        });
        console.log(this.data.current)
        if(this.data.current=="createtask"){
            wx.navigateTo({
                url: '/pages/myself/myself',
            })
        }
        if(this.data.current=="remind"){
            wx.navigateTo({
                url: '/pages/login/login',
            })
        }
        if(this.data.current=="mine"){
            wx.navigateTo({
                url: '/pages/logs/logs',
            })
        }
    },
    // 下拉事件
    listmenu: function(e) {
        if (this.data.openif) {
            this.setData({
                openif: false,
                shownavindex: 0
            })
        } else {
            this.setData({
                content: this.data.li,
                openif: true,
                shownavindex: e.currentTarget.dataset.nav
            })
        }
    },
    handleClick:function(e){
        console.log(e)
        wx.navigateTo({
            url:'/pages/order/order'
        })
    }
})
