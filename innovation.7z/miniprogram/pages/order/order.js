const db=wx.cloud.database();
const message=db.collection('message')
Page({

    /**
     * 页面的初始数据
     */
    data: {
        img_urls: [],
    },
    upload: function(e) {
        // 小程序选择图片api，具体内容参考文档：https://developers.weixin.qq.com/miniprogram/dev/api/media/image/wx.chooseImage.html
        wx.chooseImage({
          count: 1,
        })
        .then(res => {
          console.log(res)
          // 向云存储中上传图片api，云存储相关内容可参考：https://www.ourspark.org/point/course_content/602df4b15165a14f347bb48b,%E5%B0%8F%E7%A8%8B%E5%BA%8F%E4%BA%91%E5%BC%80%E5%8F%91,%E4%BA%91%E5%AD%98%E5%82%A8%E6%9C%8D%E5%8A%A1
          wx.cloud.uploadFile({
            cloudPath: 'uploadImage/' + (new Date()).getTime().toString() + '.jpeg',
            filePath: res.tempFilePaths[0]//位置错误
          })
          .then(res1 => {
            console.log(res1)
            if (res1.errMsg == 'cloud.uploadFile:ok') {
              // 向云数据库中存储上传的图片id,要上传信息在这里添加即可
              wx.cloud.callFunction({
                name: 'uploadImage',
                data: {
                  type: 'addUrl',
                  fileID: res1.fileID,
                }
              })
              .then(res2 => {
                console.log("res82",res2)
                if (res2.result.state) {
            
                  this.data.img_urls.push(res2.result.event.fileID);
                  this.setData({
                    img_urls: this.data.img_urls
                  })
                  wx.showModal({
                    title: '提示',
                    content: '请上传药品信息后再上传下一药品图片',
                    success (res) {
                      if (res.confirm) {
                        console.log('用户点击确定')
                      } 
                    }
                  })
                }
                else {
                  throw(res2.result.message);
                }
              })
              .catch(err2 => {
                console.log('调用添加url云函数错误', err2);
                wx.cloud.deleteFile({
                  fileList: [res1.fileID]
                })
                .then(res3 => {
                  console.log(res3);
                })
                .catch(err3 => {
                  console.log('删除文件错误', err3);
                })
              })
            }
            else {
              throw(res1.errMsg);
            }
          })
          .catch(err1 => {
            console.log('上传云存储错误', err1);
          })
        })
        .catch(err => {
          console.log('获取图片错误', err);
        })
      },
    
     previewSq(event1){  //预览图片
       let currentUrl=event1.currentTarget.dataset.src;
       var imgList =[];
       for (let i=0;i<this.data.img_urls.length;i++){
         imgList.push(this.data.img_urls[i]);
       }
       wx.previewImage({
         current:currentUrl,
         urls: imgList
       })
     },
    

    onSumbit:function(event){
        console.log(event.detail.value);
        message.add({
            data:{
                name:event.detail.value.name,
                num:parseInt(event.detail.value.num),
                total:parseInt(event.detail.value.total),
                content:event.detail.value.content,
            }
        }).then(res=>{
            console.log(res)
        })
    }
})