// pages/logs/logs.js
Page({

    /**
     * 页面的初始数据
     */
    data: {

            switch1 : false,
            targetTime: 0,
            targetTime1: 0,
            myFormat: ['时', '分', '秒'],
            myFormat1: ['天', '时', '分', '秒'],
            status: '进行中...',
            clearTimer: false

    },
    onLoad() {
        this.setData({
            targetTime: new Date().getTime() + 6430000,
            targetTime1: new Date().getTime() + 86430000,
            targetTime2: new Date().getTime() + 10000
        });
    },
    onUnload() {
        this.setData({
            clearTimer: true
        });
    },
    myLinsterner(e) {
        this.setData({
            status: '结束'
        });
    },
    onChange(event){
        const detail = event.detail;
        this.setData({
            'switch1' : detail.value
        })
        
    },

    /**
     * 生命周期函数--监听页面加载
     */
    onLoad(options) {

    },
    handleChange ({ detail }) {
        console.log(detail.key)
        this.setData({
            current: detail.key
        });
        console.log(this.data.current)
        if(this.data.current=="homepage"){
            wx.redirectTo({
                url: '/pages/index/index',
            })
        }
        if(this.data.current=="createtask"){
            wx.redirectTo({
                url: '/pages/myself/myself',
            })
        }
        if(this.data.current=="remind"){
            wx.redirectTo({
                url: '/pages/login/login',
            })
        }
        if(this.data.current=="mine"){
            wx.redirectTo({
                url: '/pages/logs/logs',
            })
        }
    },


    /**
     * 生命周期函数--监听页面初次渲染完成
     */
    onReady() {

    },

    /**
     * 生命周期函数--监听页面显示
     */
    onShow() {

    },

    /**
     * 生命周期函数--监听页面隐藏
     */
    onHide() {

    },

    /**
     * 生命周期函数--监听页面卸载
     */
    onUnload() {

    },

    /**
     * 页面相关事件处理函数--监听用户下拉动作
     */
    onPullDownRefresh() {

    },

    /**
     * 页面上拉触底事件的处理函数
     */
    onReachBottom() {

    },

    /**
     * 用户点击右上角分享
     */
    onShareAppMessage() {

    }
})