const envList = [{"envId":"cloud1-8g6hndbm3b2dfc38","alias":"cloud1"}]
const isMac = false
module.exports = {
    envList,
    isMac
}